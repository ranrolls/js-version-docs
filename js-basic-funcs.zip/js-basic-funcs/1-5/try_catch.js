try{
    
}catch(e){
    if(e instanceof TypeError){
        
    }else if(e instanceof RangeError){
        
    }else if(e instanceof EvalError){
        
    }else{
        
    }
}finally{
    
}