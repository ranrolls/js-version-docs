JSON.parse();

JSON.stringify();